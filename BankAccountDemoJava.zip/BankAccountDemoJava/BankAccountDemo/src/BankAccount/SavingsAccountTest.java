package BankAccount;

import java.util.ArrayList;
import java.util.Scanner; 

public class SavingsAccountTest
{
    public static void main(String[] args)  throws  Exception
    {
        double startBalance =0;       
        int months =0; 
        double deposit_Amount=0; 
        double withdraw_Amount=0; 
        int customerNumber=0;         
        int nextRecord= 1;

        ArrayList<SavingsAccount> savingsAccountList = new ArrayList<SavingsAccount>() ;
        Scanner input = new Scanner(System.in); 
        SavingsAccount sa = null;
        
        while (nextRecord ==1)
        {
 
        System.out.print("Enter Customer Number: ");
        customerNumber = input.nextInt(); 
        

        System.out.print("Enter starting balance: $ "); 
        startBalance = input.nextDouble(); 

        System.out.print("Enter the number of months: ");
        months = input.nextInt(); 
        
                                        
        sa = new SavingsAccount(customerNumber,startBalance,savingsAccountList); 

        for (int i = 0; i < months; i++)
        {
         
            System.out.print("Enter amount to deposit for the month " + (i+1) + ":$ "); 
            deposit_Amount = input.nextDouble(); 
      
            sa.setDeposit(deposit_Amount); 
       
            System.out.print("Enter amount to withdraw for the month " + (i+1) + ":$ "); 
            withdraw_Amount = input.nextDouble(); 
  
            sa.setWithdraw(withdraw_Amount); 

            sa.calculateMonthlyInterest();

        }
    
                        
        sa.addNewSavingsAccount();
           
        System.out.print("Press [1] To Continue Or Press Any Key To Exit  ");
        nextRecord = input.nextInt(); 
        
        }
      
        sa.displayData(); 
        input.close();  
    }

}
