package BankAccount;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Optional;

public class SavingsAccount
{
	   		   	   	
	   private double balance; 		
	   private double monthlyInterestRate; 
	   private double totalDeposits; 
	   private double totalWithdraws; 
	   private double totalInterest; 
	
	   private int  customerNumber;
	   private long  customerAccountNumber;

	   private ArrayList<SavingsAccount> savingsAccountList =null;
	   	   
	   public static final String START_TIME = "08:00:00";
	   public static final String END_TIME = "17:00:00";
	   public static final double ANNUAL_INTEREST_RATE = 0.2;
	   

    public SavingsAccount(int customerNumber,double startBalance,ArrayList<SavingsAccount> savingsAccountList) throws  Exception
    {
    	        	
    	this.customerNumber = customerNumber;
    	this.balance = startBalance;
    	this.monthlyInterestRate = ANNUAL_INTEREST_RATE / 12;	  
    
    	 this.customerAccountNumber = accountNumber();
         this.savingsAccountList =savingsAccountList;
    	
           
        checkProcessTime();
        
     
        
    }
        
        
   private long accountNumber() {
        long accountNumber = (long) Math.floor(Math.random() * 9000000000L) + 1000000000L;
        return accountNumber;
    }
    
    
    private boolean isSavingsAccountExists() {
            	
    	Optional <SavingsAccount> answer = savingsAccountList.stream().filter( s->this.customerNumber == s.customerNumber).findAny();
    	    	
    	if (answer.isPresent() )
               return true;

    		
    	return false;
    	
    }
    
    
    private void checkProcessTime()   throws  Exception{
                	
    
    	 LocalTime startTime = LocalTime.parse(START_TIME); 
         LocalTime endTime = LocalTime.parse(END_TIME);
    	
         LocalTime currenTime =  LocalTime.now();
	    
         
	    if ( currenTime.isBefore(startTime)  || currenTime.isAfter(endTime)) 
	    	throw new Exception("You can open an account between 08:00 and 17:00");         
    }
    
    
    
 
   public void setAnnualInterestRate(double annual_Interest_Rate)
   {
       monthlyInterestRate = ANNUAL_INTEREST_RATE / 12; 
   }

   public void setDeposit(double amount)
   {
       balance += amount; 
       totalDeposits += amount; 
   }



   public void setWithdraw(double amount)
   {
	   
	   if (amount <=balance )
	   {		   
		   balance -= amount; 
	       totalWithdraws += amount;		   		   
	   }
	   else
	   {		   
		   System.err.println("Transaction canceled due tu insufficient funds");		   
	   }
	      
   }
  
 
   public void calculateMonthlyInterest()
   {
       totalInterest = totalInterest + balance * monthlyInterestRate; 
       balance = balance + balance * monthlyInterestRate; 
       
       balance = Math.round(balance* 100.0) / 100.0; 
       totalInterest = Math.round(totalInterest * 100.0) / 100.0; 
   }
  

   public void addNewSavingsAccount()
   {
	   if (isSavingsAccountExists())
	   {
		   System.err.println("Customer " + this.customerNumber  + " has already  savings account\n ");	
	   }
	   else
	   {
		   savingsAccountList.add(this);
	   }
   }   
   
 
   public double getBalance()
   {
       return balance; 
   }

  
 
   public double getMonthlyInterestRate()
   {
       return monthlyInterestRate; 
   }


   public double getTotalDeposits()
   {
       return totalDeposits; 
   }

 
   public double getTotalWithdraws()
   {
       return totalWithdraws; 
   }

 
   public double getTotalnterest()
   {
       return totalInterest; 
   }


   public int getCutomerNumber()
   {
       return this.customerNumber; 
   }
  
   public long getCutomerAccountNumber()
   {
       return this.customerAccountNumber; 
   }
   
   public void displayData()
   {
   

       System.out.println("\n-------------------------------------Savings Account List-------------------------------------------------------------- \n" + 
    		   padRight("[Customer Number]",20) +  "\t" +padRight("[Account Number]",20) +  "\t" +  padRight("[Balance]",20) +  "\t" +  padRight("[Total Interest]",20)); 
       
       for (SavingsAccount savingsAccount : savingsAccountList )
       {
        System.out.println( padRight(String.valueOf(savingsAccount.customerNumber),20)  + "\t"  + padRight(String.valueOf(savingsAccount.customerAccountNumber),20)  + "\t" +  padRight(String.valueOf(savingsAccount.balance),20)  + "\t" + padRight(String.valueOf(savingsAccount.totalInterest),20)); 
       }
   }
   
   public static String padRight(String s, int n) {
	     return String.format("%-" + (n) + "s", s);  
	}
   
   
 
}